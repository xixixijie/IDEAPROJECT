package Complex.wager;

import Complex.Thing.Thing;

/**
 * Created by xixi on 2017/10/13.
 */
public class Asset extends Wager{
    Thing thing;
    public Asset(){
        this.name="有形资产";
        this.amount=0;

    }


}
