package Complex.wager;

/**
 * Created by xixi on 2017/10/13.
 */
public class Cash extends Wager {
    public Cash(){
        this.name="货币";
        this.amount=1000;
    }
}
