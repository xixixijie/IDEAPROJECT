package Complex.wager;

/**
 * Created by xixi on 2017/10/13.
 */
public class Jetton extends Wager {
        public Jetton(){
            this.name="筹码";
            this.amount=0;
        }
}
