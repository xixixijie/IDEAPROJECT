package Complex;

import Complex.Adapter.WagerAdapter;
import Complex.Facade.GamblingHouse;
import Complex.Factory.Creator;
import Complex.Strategy.CommonStrategy;
import Complex.Strategy.Strategy;
import Complex.Strategy.VIPStrategy;
import Complex.Thing.Watch;
import Complex.wager.Cash;
import Complex.wager.Jetton;
import Complex.wager.Wager;

import java.awt.event.WindowAdapter;

/**
 * Created by xixi on 2017/10/13.
 */
public class Client {
    //static Strategy strategy=new VIPStrategy();
    public static void main(String[] args) {
        GamblingHouse gamblingHouse=new GamblingHouse();
        gamblingHouse.Start();

    }
    {
        //        System.out.println("换赌资（策略模式）");
//        int money=100;
//
//        Strategy strategy=new VIPStrategy();
//        System.out.println("1.vip");
//        System.out.println("VIP用户 "+money+"元能换到筹码"+strategy.Algorithm(money));
//        strategy=new CommonStrategy();
//        System.out.println("2.非vip");
//        System.out.println("非VIP用户"+money+"元能换到"+strategy.Algorithm(money));
//
//        Creator creator=new Creator();
//        System.out.println("换赌资（工厂模式）");
//        String type= "Jetton";
//        Wager wager=creator.creatCreat(type);
//        System.out.println(wager.getName());
//        type="Asset";
//        wager=creator.creatCreat(type);
//        System.out.println(wager.getName());
//        type="Cash";
//        wager=creator.creatCreat(type);
//        System.out.println(wager.getName());
//
//        Watch watch=new Watch("手表",100);
//        WagerAdapter wa=new WagerAdapter(watch);
//        System.out.println("适配器模式");
//        System.out.println(wa.getName()+" 价值"+wa.getAmount());
    }


}
