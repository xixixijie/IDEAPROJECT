package Complex.Thing;

import Complex.wager.Wager;

/**
 * Created by xixi on 2017/10/15.
 */
public class Watch  extends Thing{
    public Watch(String name,double money){
        super(name,money);
    }
}
