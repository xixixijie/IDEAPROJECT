package Complex.Strategy;

/**
 * Created by xixi on 2017/10/15.
 */
public interface Strategy {
    public double Algorithm(double money);


}
